# KosherGuard website deployment notes

This is a website source package, not a live website. No domain or hosting account has been connected.

## Suggested URLs
- Public website: `https://YOUR-DOMAIN/`
- Android download page: `https://YOUR-DOMAIN/download.html`
- Admin dashboard: `https://YOUR-DOMAIN/admin/`

These are proposed paths only. They are not currently live.

## Deployment pieces
1. Host `website/` as the public static site.
2. Build `dashboard/` with `npm install && npm run build`; publish its build output under `/admin/`.
3. Host `backend/` separately on a secure server and set `VITE_API_URL` to its HTTPS URL at dashboard build time.
4. Configure HTTPS, secure cookies/token handling, CORS allowlists, rate limits, monitoring and backups.
5. Put the signed Android release APK in a private release pipeline, scan and test it, then publish it to an authenticated or public download endpoint as intended.
6. Keep Google service-account keys and backend secrets out of the website directory and source control.

## Uninstall protection and device scope
Strong uninstall restrictions require Android Enterprise fully managed/device-owner enrollment and a policy applied by the enterprise management service. A normal sideloaded app cannot make itself uninstall-proof. Personal/BYOD enrollment has different limitations; a work profile can manage work apps but cannot lock down the owner's personal side of the phone. Device enrollment should be transparent and authorized by the device owner, with a documented support and recovery process.

## Do not publish as production yet
The included app is a development prototype, not a release-signed APK. The browser filtering engine and device-wide VPN enforcement are not production-complete. Do not advertise whole-device blocking or uninstall-proof protection until those features have been implemented and tested on supported Android models.
