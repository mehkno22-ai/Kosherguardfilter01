# KosherGuard Free Android — browser-filtering prototype

This project adds a dedicated Android browser with conservative image blocking and a backend-managed domain blocklist.

## Protection profiles
- `work_essentials`: general browsing is permitted except for administrator blocklists and starter social/AI/entertainment domain examples.
- `strict_kosher`: only administrator-approved domains are permitted.
- `maximum_protection`: the in-app browser is disabled.
- Administrators can choose which profiles a customer may select; customers cannot select profiles outside that list.

The seeded category domains are examples only, not a comprehensive category database. Real-world coverage needs maintained threat/category feeds and testing. Strict mode's allowlist is enforced by the app browser, not by all device traffic.

## What this version does
- Dedicated Android WebView browser.
- Blocks network-loaded images and hides common inline visual elements (img, picture, SVG, canvas, video, object, embed) in the KosherGuard browser. This intentionally also blocks harmless images.
- Checks every requested URL against a locally cached domain blocklist.
- Refreshes policy from the backend when online.
- Includes a request-access form that sends a domain and reason to the approval API.
- Free/no billing or subscription code.

## What it does NOT yet do
- It does not filter traffic in other apps or other browsers.
- It does not inspect images to identify women; it blocks visual content broadly. Some unusual script-rendered graphics or text-based representations may still appear, so this is not a guarantee that every depiction of a person is removed.
- It does not defeat VPN/proxy/DNS bypasses outside this app.
- It does not provide a production-grade category database or image moderation engine.
- A WebView browser alone is not a complete device-wide kosher filter. The app's maximum mode disables its own browser, not every browser or network-capable app installed on the phone.

For whole-device enforcement, deploy as an Android Enterprise fully managed / device-owner device with a managed configuration, kiosk/allowlist policy, always-on VPN lockdown, and a tested filtering service. Do not promise tamper-proof protection on an unmanaged personal phone.

## Backend
This package includes the API from the previous starter with an additional public device-policy endpoint. Install:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export JWT_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Set a real HTTPS `API_BASE_URL` in the Android Gradle file. The API must be reachable by the phone.

Bootstrap the first owner once using `POST /auth/register-owner`; then disable that endpoint before production. Add devices from the dashboard and enter the returned device key in the app.

## Android build
Open `android/` in Android Studio, sync Gradle, and build the `app` module.
Set `API_BASE_URL` in `android/app/build.gradle.kts` to your HTTPS API base URL.
The device key is a credential: treat it like a password and rotate it if exposed.

## Production checklist
- PostgreSQL, HTTPS, managed secrets, rate limiting, monitoring, backups.
- Secure device enrollment and device-key rotation/revocation.
- Audit logs for every admin action and approval.
- Verify all roles are scoped to the correct tenant and customer.
- Add policy versioning and signed policy delivery.
- Add category-based domain feeds and DNS/IP filtering.
- Android Enterprise enrollment, kiosk/allowlist, always-on VPN and lockdown.
- Penetration test, privacy review, app-store policy review, and accessibility testing.


## Android Enterprise (Version 0.4 integration scaffold)

This release adds an optional Google Android Management API integration:
- Applies managed-device app allowlist / Play Store whitelist policies.
- Creates one-time fully-managed enrollment tokens for registered customer devices.
- Dashboard controls to apply the selected managed policy and request a one-time enrollment token.
- Lists enrolled Android Enterprise devices.
- Assigns a different Android Enterprise policy per KosherGuard device and protection plan.

### Google setup required
1. Create a Google Cloud project and enable Android Management API.
2. Complete Google's Android Enterprise EMM/enterprise provisioning and obtain the `enterprises/<id>` identifier. This is not a public self-service API key; Google's current Android Enterprise terms and onboarding requirements apply.
3. Create a service account with the required Android Management API access and securely mount its JSON key outside the web root.
4. Set:
```bash
export AMAPI_ENTERPRISE_ID="enterprises/YOUR_ENTERPRISE_ID"
export AMAPI_SERVICE_ACCOUNT_FILE="/secure/path/service-account.json"
export AMAPI_POLICY_ID="kosherguard"
```
5. Restart the backend. Use `/enterprise/apply-policy/{device_id}` and `/enterprise/enrollment-token/{device_id}` as an owner/super-admin.

### Critical safety / deployment notes
- Fully managed enrollment normally requires a new or factory-reset Android device and the Android Enterprise provisioning flow. This is not a silent takeover of an already configured personal phone.
- The app allowlist is a starting policy, not a finished customer-ready kiosk configuration. Test on spare devices before enrollment. In particular, `maximum_protection` currently has no general browser in its allowlist; define the exact essential apps and a tested launcher experience before using it in production.
- **VPN lockdown is OFF by default.** The current KosherGuard project does not yet contain a production packet-forwarding/filtering VPN engine. Enabling always-on VPN lockdown before that engine is built and tested can cut off network access. Only set `KOSHERGUARD_VPN_READY=true` after the VPN service is complete, audited, and tested.
- Android Enterprise policies vary by Android version and device maker. Validate every policy on test devices and review current Google API documentation and policy requirements.
- This integration does not guarantee that every installed system function is blocked. Production needs a tested app allowlist, launcher, system-app policy, emergency recovery process, audit trail, monitoring, and support procedure.

## Updated Android app notes (v0.3.0)
- Added an in-app HTTPS API-server setting, so the server URL does not need to be hard-coded into the APK.
- Fixed the temporary-approval path so an active admin-approved temporary unlock can pass the strict allowlist check for its approved domain.
- Fixed image-request filtering so ordinary top-level HTML page requests are not mistakenly blocked because their Accept header mentions image formats.
- Added fail-closed behavior: if the app cannot verify a current server policy, browsing stays paused.
- Added HTTPS-only browsing, mixed-content blocking, Safe Browsing, and cancellation of invalid TLS certificates.
- Added a GitHub Actions workflow to build a debug APK in the cloud.

This still filters only traffic inside the KosherGuard WebView. It is not a complete device-wide filter, and broad image blocking does not guarantee that every depiction of a person is removed.
