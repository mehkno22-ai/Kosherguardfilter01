"""
Android Management API integration.

Requires a Google Cloud project with Android Management API enabled,
an enterprise created through Google's Android Enterprise provisioning flow,
and a service account authorized for that enterprise.
"""
import os
from datetime import timedelta
from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession

API = "https://androidmanagement.googleapis.com/v1"
SCOPES = ["https://www.googleapis.com/auth/androidmanagement"]

def _session():
    key_file = os.getenv("AMAPI_SERVICE_ACCOUNT_FILE")
    if not key_file:
        raise RuntimeError("AMAPI_SERVICE_ACCOUNT_FILE is not configured")
    creds = service_account.Credentials.from_service_account_file(key_file, scopes=SCOPES)
    return AuthorizedSession(creds)

def _enterprise():
    value = os.getenv("AMAPI_ENTERPRISE_ID", "").strip()
    if not value:
        raise RuntimeError("AMAPI_ENTERPRISE_ID is not configured")
    return value

def build_policy(plan: str, browser_package: str = "com.kosherguard",
                 vpn_ready: bool = False, vpn_package: str = "com.kosherguard"):
    """
    Build a managed-device policy.
    Important: VPN lockdown is deliberately omitted unless the operator confirms
    that the VPN service is implemented, tested, and ready for production.
    """
    allowed = {
        "work_essentials": [
            {"packageName": browser_package, "installType": "KIOSK"}
        ],
        "strict_kosher": [
            {"packageName": browser_package, "installType": "KIOSK"}
        ],
        "maximum_protection": []
    }
    if plan not in allowed:
        raise ValueError("Unknown protection plan")

    policy = {
        "applications": allowed[plan],
        "playStoreMode": "WHITELIST",
        "safeBootDisabled": True,
        "factoryResetDisabled": True,
        "usbFileTransferDisabled": True,
        "debuggingFeaturesAllowed": False,
        "installUnknownSourcesAllowed": False,
        "modifyAccountsDisabled": True,
        "uninstallAppsDisabled": True,
        "statusBarDisabled": plan in ("strict_kosher", "maximum_protection"),
        "keyguardDisabled": False,
        "cameraDisabled": False,
        "screenCaptureDisabled": True,
        "advancedSecurityOverrides": {
            "googlePlayProtectVerifyApps": "VERIFY_APPS_ENFORCED"
        }
    }

    # Maximum Protection has no general-purpose browser in its app allowlist.
    # Do not use an empty kiosk list as a production policy without validating
    # the desired launcher/essential-app experience on test hardware.
    if plan == "maximum_protection":
        policy["applications"] = []
        policy["playStoreMode"] = "WHITELIST"

    if vpn_ready:
        policy["alwaysOnVpnPackage"] = {
            "packageName": vpn_package,
            "lockdownEnabled": True
        }
    return policy

def apply_policy(plan: str, policy_id: str | None = None, vpn_ready: bool = False):
    enterprise = _enterprise()
    policy_id = policy_id or os.getenv("AMAPI_POLICY_ID", "kosherguard-" + plan)
    name = f"{enterprise}/policies/{policy_id}"
    body = build_policy(plan, vpn_ready=vpn_ready)
    response = _session().patch(f"{API}/{name}", json=body, params={"updateMask": ",".join(body.keys())})
    response.raise_for_status()
    return response.json()

def create_enrollment_token(policy_name: str, duration_hours: int = 1):
    enterprise = _enterprise()
    if not 1 <= duration_hours <= 24:
        raise ValueError("Enrollment token duration must be between 1 and 24 hours")
    body = {
        "policyName": policy_name,
        "duration": f"{duration_hours}h",
        "oneTimeOnly": True,
        "allowPersonalUsage": "PERSONAL_USAGE_DISALLOWED"
    }
    response = _session().post(f"{API}/{enterprise}/enrollmentTokens", json=body)
    response.raise_for_status()
    return response.json()

def list_managed_devices():
    enterprise = _enterprise()
    response = _session().get(f"{API}/{enterprise}/devices")
    response.raise_for_status()
    return response.json().get("devices", [])
