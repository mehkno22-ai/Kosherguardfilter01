from fastapi import FastAPI, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from sqlalchemy import select
from datetime import datetime, timezone, timedelta
import secrets, re, os

from .database import Base, engine, get_db
from .models import Organization, User, Device, Policy, UnlockRequest
from .security import hash_password, verify_password, create_token, decode_token
from .amapi import apply_policy, create_enrollment_token, list_managed_devices

Base.metadata.create_all(bind=engine)
app = FastAPI(title="KosherGuard Free API", version="0.2.0")

def current_user(authorization: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    payload = decode_token(authorization[7:])
    if not payload:
        raise HTTPException(401, "Invalid or expired token")
    user = db.get(User, int(payload["sub"]))
    if not user or not user.active:
        raise HTTPException(401, "Account inactive")
    return user

def require_roles(*roles):
    def checker(user: User = Depends(current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Insufficient permissions")
        return user
    return checker

def normalize_domain(value: str):
    value = value.strip().lower().rstrip(".")
    if "://" in value or "/" in value or " " in value or "." not in value:
        raise HTTPException(400, "Enter a domain only, such as example.com")
    if not re.fullmatch(r"[a-z0-9.-]{3,253}", value):
        raise HTTPException(400, "Invalid domain")
    return value

@app.get("/health")
def health():
    return {"status": "ok", "service": "kosherguard-api"}

@app.post("/auth/register-owner")
def register_owner(body: dict, db: Session = Depends(get_db)):
    # One-time bootstrap only; disable this route after creating the owner.
    if db.scalar(select(User.id).limit(1)) is not None:
        raise HTTPException(403, "Owner registration is closed")
    organization = str(body.get("organization", "")).strip()
    email = str(body.get("email", "")).strip().lower()
    password = str(body.get("password", ""))
    if len(organization) < 2 or "@" not in email or len(password) < 12:
        raise HTTPException(400, "Organization, valid email and 12+ character password required")
    org = Organization(name=organization)
    db.add(org); db.flush()
    user = User(org_id=org.id, email=email, password_hash=hash_password(password), role="owner")
    db.add(user); db.add(Policy(org_id=org.id, name="Strict", blocked_domains=""))
    db.commit(); db.refresh(user)
    return {"access_token": create_token(user.id, org.id, user.role), "token_type": "bearer"}

@app.post("/auth/login")
def login(body: dict, db: Session = Depends(get_db)):
    email = str(body.get("email", "")).lower()
    password = str(body.get("password", ""))
    user = db.scalar(select(User).where(User.email == email))
    if not user or not user.active or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": create_token(user.id, user.org_id, user.role), "token_type": "bearer", "role": user.role}

@app.post("/admins")
def create_admin(body: dict, user: User = Depends(require_roles("owner", "super_admin")), db: Session = Depends(get_db)):
    email = str(body.get("email", "")).strip().lower()
    password = str(body.get("password", ""))
    role = str(body.get("role", "approver"))
    if role not in ("super_admin", "approver", "support") or len(password) < 12 or "@" not in email:
        raise HTTPException(400, "Invalid email, password or role")
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "Email already registered")
    admin = User(org_id=user.org_id, email=email, password_hash=hash_password(password), role=role)
    db.add(admin); db.commit(); db.refresh(admin)
    return {"id": admin.id, "email": admin.email, "role": admin.role}

@app.get("/admins")
def list_admins(user: User = Depends(require_roles("owner", "super_admin")), db: Session = Depends(get_db)):
    return [{"id": x.id, "email": x.email, "role": x.role, "active": x.active}
            for x in db.scalars(select(User).where(User.org_id == user.org_id)).all()]

@app.post("/devices")
def add_device(body: dict, user: User = Depends(require_roles("owner", "super_admin", "support")), db: Session = Depends(get_db)):
    name = str(body.get("name", "")).strip()
    if not name: raise HTTPException(400, "Device name required")
    key = secrets.token_urlsafe(36)
    device = Device(org_id=user.org_id, name=name, device_key=key)
    db.add(device); db.commit(); db.refresh(device)
    return {"id": device.id, "name": device.name, "device_key": key, "status": device.status,
            "plan": device.plan, "available_plans": device.available_plans.split(",")}

@app.get("/devices")
def list_devices(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return [{"id": d.id, "name": d.name, "platform": d.platform, "status": d.status,
             "plan": d.plan, "available_plans": [x for x in d.available_plans.split(",") if x],
             "allowed_domains": [x for x in d.allowed_domains.splitlines() if x]}
            for d in db.scalars(select(Device).where(Device.org_id == user.org_id)).all()]

@app.put("/devices/{device_id}/plan")
def update_device_plan(device_id: int, body: dict,
                       user: User = Depends(require_roles("owner", "super_admin")), db: Session = Depends(get_db)):
    device = db.scalar(select(Device).where(Device.id == device_id, Device.org_id == user.org_id))
    if not device: raise HTTPException(404, "Device not found")
    valid = {"work_essentials", "strict_kosher", "maximum_protection"}
    plan = body.get("plan")
    available = body.get("available_plans", [plan])
    if plan not in valid or not isinstance(available, list) or not available or any(x not in valid for x in available):
        raise HTTPException(400, "Invalid plan selection")
    if plan not in available: raise HTTPException(400, "Assigned plan must be one of the customer's available plans")
    device.plan = plan
    device.available_plans = ",".join(sorted(set(available)))
    domains = body.get("allowed_domains", [])
    if not isinstance(domains, list): raise HTTPException(400, "allowed_domains must be a list")
    device.allowed_domains = "\\n".join(sorted({normalize_domain(str(x)) for x in domains}))
    db.commit()
    return {"ok": True, "plan": device.plan, "available_plans": device.available_plans.split(",")}

@app.post("/devices/{device_key}/select-plan")
def customer_select_plan(device_key: str, body: dict, db: Session = Depends(get_db)):
    device = db.scalar(select(Device).where(Device.device_key == device_key, Device.status == "active"))
    if not device: raise HTTPException(404, "Device not found")
    requested = body.get("plan")
    available = [x for x in device.available_plans.split(",") if x]
    if requested not in available:
        raise HTTPException(403, "This protection plan is not enabled for this device")
    device.plan = requested
    db.commit()
    return {"ok": True, "plan": device.plan}

@app.get("/policy")
def get_policy(user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = db.scalar(select(Policy).where(Policy.org_id == user.org_id))
    return {"name": p.name, "blocked_domains": [x for x in p.blocked_domains.splitlines() if x]}

@app.put("/policy")
def update_policy(body: dict, user: User = Depends(require_roles("owner", "super_admin")), db: Session = Depends(get_db)):
    p = db.scalar(select(Policy).where(Policy.org_id == user.org_id))
    domains = body.get("blocked_domains", [])
    if not isinstance(domains, list): raise HTTPException(400, "blocked_domains must be a list")
    p.name = str(body.get("name", "Strict"))[:120]
    p.blocked_domains = "\n".join(sorted({normalize_domain(str(x)) for x in domains}))
    p.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {"ok": True}

@app.post("/unlock-requests")
def create_unlock(body: dict, db: Session = Depends(get_db)):
    key = str(body.get("device_key", ""))
    device = db.scalar(select(Device).where(Device.device_key == key, Device.status == "active"))
    if not device: raise HTTPException(401, "Unknown or inactive device")
    domain = normalize_domain(str(body.get("domain", "")))
    reason = str(body.get("reason", ""))[:500]
    req = UnlockRequest(org_id=device.org_id, device_id=device.id, domain=domain, reason=reason)
    db.add(req); db.commit(); db.refresh(req)
    return {"id": req.id, "status": req.status}

@app.get("/unlock-requests")
def list_unlocks(user: User = Depends(require_roles("owner", "super_admin", "approver", "support")), db: Session = Depends(get_db)):
    rows = db.scalars(select(UnlockRequest).where(UnlockRequest.org_id == user.org_id).order_by(UnlockRequest.requested_at.desc())).all()
    return [{"id": r.id, "device_id": r.device_id, "domain": r.domain, "reason": r.reason,
             "status": r.status, "requested_at": r.requested_at.isoformat()} for r in rows]

@app.post("/unlock-requests/{request_id}/decision")
def decide_unlock(request_id: int, body: dict, user: User = Depends(require_roles("owner", "super_admin", "approver")), db: Session = Depends(get_db)):
    req = db.scalar(select(UnlockRequest).where(UnlockRequest.id == request_id, UnlockRequest.org_id == user.org_id))
    if not req: raise HTTPException(404, "Request not found")
    if req.status != "pending": raise HTTPException(409, "Request already decided")
    decision = body.get("decision")
    duration = body.get("duration_minutes")
    if decision not in ("approve", "deny"): raise HTTPException(400, "Invalid decision")
    if decision == "approve" and (not isinstance(duration, int) or not 1 <= duration <= 1440):
        raise HTTPException(400, "Approval duration must be 1–1440 minutes")
    req.status = "approved" if decision == "approve" else "denied"
    req.decided_by = user.id; req.decided_at = datetime.now(timezone.utc)
    req.duration_minutes = duration if decision == "approve" else None
    db.commit()
    return {"id": req.id, "status": req.status, "duration_minutes": req.duration_minutes}

@app.get("/devices/{device_key}/policy")
def device_policy(device_key: str, db: Session = Depends(get_db)):
    device = db.scalar(select(Device).where(Device.device_key == device_key, Device.status == "active"))
    if not device: raise HTTPException(404, "Device not found")
    policy = db.scalar(select(Policy).where(Policy.org_id == device.org_id))
    now = datetime.now(timezone.utc)
    grants = db.scalars(select(UnlockRequest).where(
        UnlockRequest.device_id == device.id, UnlockRequest.status == "approved")).all()
    active = []
    for grant in grants:
        if grant.decided_at and grant.duration_minutes:
            expires = grant.decided_at + timedelta(minutes=grant.duration_minutes)
            if expires > now: active.append({"domain": grant.domain, "expires_at": expires.isoformat()})
    # Seed lists are only starter examples, not a complete or continuously updated category database.
    category_domains = {
        "social_media": ["facebook.com", "instagram.com", "tiktok.com", "snapchat.com", "x.com", "twitter.com", "pinterest.com", "reddit.com"],
        "ai": ["chatgpt.com", "openai.com", "claude.ai", "gemini.google.com", "perplexity.ai", "copilot.microsoft.com"],
        "entertainment": ["youtube.com", "youtu.be", "netflix.com", "hulu.com", "twitch.tv", "disneyplus.com"]
    }
    return {"device": device.name, "policy_name": policy.name, "plan": device.plan,
            "available_plans": [x for x in device.available_plans.split(",") if x],
            "allowed_domains": [x for x in device.allowed_domains.splitlines() if x],
            "blocked_domains": [x for x in policy.blocked_domains.splitlines() if x],
            "category_domains": category_domains,
            "temporary_unlocks": active}


@app.post("/enterprise/apply-policy/{device_id}")
def enterprise_apply_policy(device_id: int, body: dict,
                            user: User = Depends(require_roles("owner", "super_admin")),
                            db: Session = Depends(get_db)):
    """Apply the selected Android Enterprise policy to a registered KosherGuard device."""
    device = db.scalar(select(Device).where(Device.id == device_id, Device.org_id == user.org_id))
    if not device:
        raise HTTPException(404, "Device not found")
    plan = body.get("plan", device.plan)
    if plan not in ("work_essentials", "strict_kosher", "maximum_protection"):
        raise HTTPException(400, "Invalid protection plan")
    if plan not in [x for x in device.available_plans.split(",") if x]:
        raise HTTPException(403, "Plan is not enabled for this customer")
    vpn_ready = os.getenv("KOSHERGUARD_VPN_READY", "false").lower() == "true"
    try:
        result = apply_policy(plan, policy_id=f"kg-{device.id}-{plan}", vpn_ready=vpn_ready)
        device.plan = plan
        db.commit()
        return {"ok": True, "plan": plan, "enterprise_policy": result}
    except Exception as exc:
        raise HTTPException(502, f"Android Enterprise policy operation failed: {exc}")

@app.post("/enterprise/enrollment-token/{device_id}")
def enterprise_enrollment(device_id: int,
                          user: User = Depends(require_roles("owner", "super_admin")),
                          db: Session = Depends(get_db)):
    """Create a one-time fully-managed enrollment token for a customer device."""
    device = db.scalar(select(Device).where(Device.id == device_id, Device.org_id == user.org_id))
    if not device:
        raise HTTPException(404, "Device not found")
    policy_id = f"kg-{device.id}-{device.plan}"
    policy_name = f"{os.getenv('AMAPI_ENTERPRISE_ID', '').strip()}/policies/{policy_id}"
    try:
        # Ensure the matching policy exists before issuing the enrollment token.
        apply_policy(device.plan, policy_id=policy_id,
                     vpn_ready=os.getenv("KOSHERGUARD_VPN_READY", "false").lower() == "true")
        token = create_enrollment_token(policy_name, duration_hours=1)
        return {"device_id": device.id, "plan": device.plan, "enrollment": token}
    except Exception as exc:
        raise HTTPException(502, f"Enrollment token creation failed: {exc}")

@app.get("/enterprise/devices")
def enterprise_devices(user: User = Depends(require_roles("owner", "super_admin", "support"))):
    try:
        return {"devices": list_managed_devices()}
    except Exception as exc:
        raise HTTPException(502, f"Could not retrieve Android Enterprise devices: {exc}")
