package com.kosherguard

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URI
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("kosherguard", MODE_PRIVATE) }
    private val deviceKey get() = prefs.getString("device_key", "") ?: ""
    private val apiBaseUrl get() = prefs.getString("api_base_url", BuildConfig.API_BASE_URL) ?: ""
    private val blocked = ConcurrentHashMap.newKeySet<String>()
    private val allowlist = ConcurrentHashMap.newKeySet<String>()
    private val temporary = ConcurrentHashMap<String, Long>()
    @Volatile private var plan = "work_essentials"
    @Volatile private var customerPlans = listOf("work_essentials")
    @Volatile private var policyLoaded = false
    private var pendingBlockedHost = ""
    private lateinit var browser: WebView
    private lateinit var address: EditText
    private lateinit var keyBox: EditText
    private lateinit var serverBox: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(false)
        buildUi()
        refreshPolicy()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshPolicy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 4)
        }
        val header = TextView(this).apply {
            text = "KosherGuard"
            textSize = 23f
            setPadding(8, 12, 8, 4)
        }
        root.addView(header)
        root.addView(TextView(this).apply {
            text = "Protected browser · administrator-managed rules"
            textSize = 13f
            setPadding(8, 0, 8, 8)
        })

        val serverRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        serverBox = EditText(this).apply {
            hint = "API server URL (https://...)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(apiBaseUrl)
        }
        serverRow.addView(serverBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        serverRow.addView(Button(this).apply {
            text = "Save server"
            setOnClickListener { saveServer() }
        })
        root.addView(serverRow)

        val enrollRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        keyBox = EditText(this).apply {
            hint = "Device enrollment key"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(deviceKey)
        }
        enrollRow.addView(keyBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        enrollRow.addView(Button(this).apply {
            text = "Save key"
            setOnClickListener {
                prefs.edit().putString("device_key", keyBox.text.toString().trim()).apply()
                policyLoaded = false
                refreshPolicy()
            }
        })
        root.addView(enrollRow)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        address = EditText(this).apply {
            hint = "Enter HTTPS website address"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        nav.addView(address, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(Button(this).apply { text = "Go"; setOnClickListener { navigate() } })
        root.addView(nav)

        status = TextView(this).apply {
            text = "Connect to your KosherGuard server and enter your device key."
            setPadding(8, 8, 8, 8)
            textSize = 13f
        }
        root.addView(status)

        browser = WebView(this)
        browser.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            blockNetworkImage = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
        }
        browser.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                if (uri.scheme != "https") {
                    showBlocked(uri.toString(), uri.host ?: "")
                    return true
                }
                val host = uri.host ?: return true
                if (!policyLoaded || isBlocked(host) || !isAllowedByPlan(host)) {
                    showBlocked(uri.toString(), host)
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (uri.scheme == "http" || uri.scheme == "https") {
                    val host = uri.host ?: ""
                    if (!policyLoaded || isBlocked(host) || !isAllowedByPlan(host)) return emptyResponse("text/plain")
                    // Block image subresources. Do not inspect the main-frame Accept header:
                    // normal HTML navigation can advertise image formats too.
                    if (!request.isForMainFrame) {
                        val path = uri.path?.lowercase() ?: ""
                        val accept = request.requestHeaders.entries.firstOrNull { it.key.equals("Accept", true) }
                            ?.value?.lowercase()?.trim() ?: ""
                        val imageExt = listOf(".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".avif", ".svg", ".ico")
                            .any { path.endsWith(it) }
                        if (imageExt || accept.startsWith("image/")) return emptyResponse("text/plain")
                    }
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                status.text = "Loading protected page…"
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                // Extra layer for inline and dynamically inserted visual elements.
                val hideVisuals = """
                    (function() {
                      const style = document.createElement('style');
                      style.textContent = 'img,picture,svg,canvas,video,object,embed { display:none !important; } * { background-image:none !important; }';
                      (document.head || document.documentElement).appendChild(style);
                      const hide = () => document.querySelectorAll('img,picture,svg,canvas,video,object,embed').forEach(e => e.remove());
                      hide();
                      new MutationObserver(hide).observe(document.documentElement, {childList:true,subtree:true});
                    })();
                """.trimIndent()
                view?.evaluateJavascript(hideVisuals, null)
                status.text = "${planLabel(plan)} · network images and common inline visuals blocked"
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                handler?.cancel()
                status.text = "Secure connection failed. The page was stopped."
            }
        }
        root.addView(browser, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        footer.addView(Button(this).apply {
            text = "Back"
            setOnClickListener { if (browser.canGoBack()) browser.goBack() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        footer.addView(Button(this).apply {
            text = "Request access"
            setOnClickListener { requestUnlock() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        footer.addView(Button(this).apply {
            text = "Plan"
            setOnClickListener { choosePlan() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        footer.addView(Button(this).apply {
            text = "Refresh"
            setOnClickListener { refreshPolicy() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(footer)
        setContentView(root)
    }

    private fun saveServer() {
        val raw = serverBox.text.toString().trim().trimEnd('/')
        val parsed = try { URI(raw) } catch (_: Exception) { null }
        if (parsed == null || parsed.scheme != "https" || parsed.host.isNullOrBlank() || parsed.rawQuery != null || parsed.rawFragment != null) {
            status.text = "Enter a valid HTTPS API address, without a path or query."
            return
        }
        prefs.edit().putString("api_base_url", raw).apply()
        policyLoaded = false
        status.text = "Server saved. Refreshing your protection policy…"
        refreshPolicy()
    }

    private fun normalizeHost(host: String): String = host.lowercase().trim().trim('.').removePrefix("www.")

    private fun matchesDomain(hostValue: String, domainValue: String): Boolean {
        val host = normalizeHost(hostValue)
        val domain = normalizeHost(domainValue)
        return host == domain || host.endsWith(".$domain")
    }

    private fun isTemporarilyUnlocked(hostValue: String): Boolean {
        val now = System.currentTimeMillis()
        temporary.entries.removeIf { it.value <= now }
        return temporary.entries.any { (domain, expires) -> expires > now && matchesDomain(hostValue, domain) }
    }

    private fun isBlocked(hostValue: String): Boolean {
        if (isTemporarilyUnlocked(hostValue)) return false
        return blocked.any { matchesDomain(hostValue, it) }
    }

    private fun emptyResponse(mime: String) = WebResourceResponse(
        mime, "UTF-8", 200, "OK", mapOf("Cache-Control" to "no-store"),
        java.io.ByteArrayInputStream(ByteArray(0))
    )

    private fun navigate() {
        var raw = address.text.toString().trim()
        if (raw.isBlank()) return
        if (!raw.contains("://")) raw = "https://$raw"
        val uri = try { URI(raw) } catch (_: Exception) { status.text = "Invalid website address"; return }
        if (uri.scheme != "https") { status.text = "Only secure HTTPS websites are allowed."; return }
        val host = uri.host ?: run { status.text = "Invalid website address"; return }
        if (!policyLoaded || isBlocked(host) || !isAllowedByPlan(host)) {
            showBlocked(raw, host)
            return
        }
        pendingBlockedHost = ""
        browser.loadUrl(uri.toString())
    }

    private fun showBlocked(url: String, host: String) {
        pendingBlockedHost = host
        status.text = "This website is blocked by your KosherGuard policy."
        val safeHost = host.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        browser.loadDataWithBaseURL(null,
            "<html><body style='font-family:sans-serif;padding:28px'><h2>Website blocked</h2><p>This address is blocked by your administrator.</p><p>$safeHost</p><p>Use Request access if you need temporary permission.</p></body></html>",
            "text/html", "UTF-8", null)
    }

    private fun refreshPolicy() {
        if (deviceKey.isBlank()) {
            policyLoaded = false
            status.text = "Enter your HTTPS API server and device enrollment key to load your filtering policy."
            return
        }
        if (apiBaseUrl.isBlank() || !apiBaseUrl.startsWith("https://")) {
            policyLoaded = false
            status.text = "Save your HTTPS API server address first."
            return
        }
        status.text = "Refreshing administrator policy…"
        Thread {
            try {
                val result = api("/devices/${Uri.encode(deviceKey)}/policy")
                val json = JSONObject(result)
                val newPlan = json.optString("plan", "work_essentials")
                val validPlans = setOf("work_essentials", "strict_kosher", "maximum_protection")
                if (newPlan !in validPlans) throw IllegalStateException("Invalid policy received")
                val available = json.optJSONArray("available_plans")
                val newCustomerPlans = if (available != null) {
                    (0 until available.length()).map { available.getString(it) }.filter { it in validPlans }.distinct()
                } else listOf(newPlan)
                val newBlocked = ConcurrentHashMap.newKeySet<String>()
                val domains = json.optJSONArray("blocked_domains") ?: JSONArray()
                for (i in 0 until domains.length()) newBlocked.add(normalizeHost(domains.getString(i)))
                val categories = json.optJSONObject("category_domains")
                if (categories != null) {
                    for (category in listOf("social_media", "ai", "entertainment")) {
                        val list = categories.optJSONArray(category) ?: JSONArray()
                        for (i in 0 until list.length()) newBlocked.add(normalizeHost(list.getString(i)))
                    }
                }
                val newAllowed = ConcurrentHashMap.newKeySet<String>()
                val allowed = json.optJSONArray("allowed_domains") ?: JSONArray()
                for (i in 0 until allowed.length()) newAllowed.add(normalizeHost(allowed.getString(i)))
                val newTemporary = ConcurrentHashMap<String, Long>()
                val grants = json.optJSONArray("temporary_unlocks") ?: JSONArray()
                for (i in 0 until grants.length()) {
                    val item = grants.getJSONObject(i)
                    val expires = java.time.Instant.parse(item.getString("expires_at")).toEpochMilli()
                    if (expires > System.currentTimeMillis()) newTemporary[normalizeHost(item.getString("domain"))] = expires
                }
                blocked.clear(); blocked.addAll(newBlocked)
                allowlist.clear(); allowlist.addAll(newAllowed)
                temporary.clear(); temporary.putAll(newTemporary)
                plan = newPlan
                customerPlans = newCustomerPlans.ifEmpty { listOf(newPlan) }
                policyLoaded = true
                runOnUiThread {
                    val maxMode = plan == "maximum_protection"
                    address.isEnabled = !maxMode
                    if (maxMode) {
                        browser.loadData("<html><body style='font-family:sans-serif;padding:28px'><h2>Browser disabled</h2><p>Your administrator assigned Maximum Protection. General browsing is disabled in KosherGuard.</p></body></html>", "text/html", "UTF-8")
                    }
                    status.text = "Policy loaded: ${planLabel(plan)} · image blocking enabled"
                }
            } catch (_: Exception) {
                policyLoaded = false // Fail closed if a current policy cannot be verified.
                runOnUiThread {
                    address.isEnabled = false
                    status.text = "Policy could not be verified. Browsing is paused until the server connection is restored."
                }
            }
        }.start()
    }

    private fun planLabel(value: String): String = when (value) {
        "strict_kosher" -> "Strict Kosher"
        "maximum_protection" -> "Maximum Protection"
        else -> "Work & Essentials"
    }

    private fun isAllowedByPlan(hostValue: String): Boolean {
        if (!policyLoaded) return false
        if (isTemporarilyUnlocked(hostValue)) return true
        if (plan == "maximum_protection") return false
        if (plan == "strict_kosher") return allowlist.any { matchesDomain(hostValue, it) }
        return true
    }

    private fun choosePlan() {
        if (!policyLoaded) { status.text = "Load your administrator policy first."; return }
        if (customerPlans.size <= 1) {
            status.text = "Your administrator has assigned one protection plan."
            return
        }
        val labels = customerPlans.map { planLabel(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose your protection plan")
            .setItems(labels) { _, which ->
                val selected = customerPlans[which]
                Thread {
                    try {
                        api("/devices/${Uri.encode(deviceKey)}/select-plan", "POST", JSONObject().put("plan", selected).toString())
                        refreshPolicy()
                    } catch (_: Exception) {
                        runOnUiThread { status.text = "Could not change plan. Check your connection." }
                    }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun requestUnlock() {
        if (deviceKey.isBlank() || !policyLoaded) { status.text = "Connect and load your device policy first."; return }
        val host = pendingBlockedHost.ifBlank {
            try { URI(browser.url ?: "").host ?: "" } catch (_: Exception) { "" }
        }
        if (host.isBlank()) { status.text = "Open or enter a blocked website first."; return }
        val reasonBox = EditText(this).apply { hint = "Why do you need temporary access?" }
        AlertDialog.Builder(this).setTitle("Request temporary access")
            .setMessage("Website: $host").setView(reasonBox)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send request") { _, _ ->
                val body = JSONObject().put("device_key", deviceKey).put("domain", host)
                    .put("reason", reasonBox.text.toString().take(500)).toString()
                Thread {
                    try {
                        api("/unlock-requests", "POST", body)
                        runOnUiThread { status.text = "Request sent to your administrators." }
                    } catch (_: Exception) {
                        runOnUiThread { status.text = "Request could not be sent. Check your connection." }
                    }
                }.start()
            }.show()
    }

    private fun api(path: String, method: String = "GET", body: String? = null): String {
        val base = apiBaseUrl.trimEnd('/')
        val conn = URL(base + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.setRequestProperty("Accept", "application/json")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException("Server returned HTTP $code")
            response
        } finally {
            conn.disconnect()
        }
    }
}
